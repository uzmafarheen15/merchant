package com.multiclientwebsite.merchantAndProduct.exception;

public class NoSuchCartExistsException extends Throwable {
    public NoSuchCartExistsException(String cart_id_does_not_exists) {
    }
}
