package com.multiclientwebsite.merchantAndProduct.exception;

public class InvalidCartItemDataException extends Exception {
    public InvalidCartItemDataException(String enter_correct_cart_item_data) {
    }
}
