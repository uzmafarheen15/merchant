package com.multiclientwebsite.merchantAndProduct.service;

import com.multiclientwebsite.merchantAndProduct.exception.NoSuchCustomerExistsException;

public class PaymentServiceImpl implements PaymentService {
    @Override
    public String orderProductsFromCart(Long customerId) throws NoSuchCustomerExistsException {
        return null;
    }
}
