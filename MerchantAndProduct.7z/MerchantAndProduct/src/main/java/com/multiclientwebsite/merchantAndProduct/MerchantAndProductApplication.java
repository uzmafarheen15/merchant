package com.multiclientwebsite.merchantAndProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantAndProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantAndProductApplication.class, args);
	}

}
