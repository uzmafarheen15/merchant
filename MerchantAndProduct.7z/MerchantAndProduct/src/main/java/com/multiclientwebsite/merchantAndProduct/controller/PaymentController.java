package com.multiclientwebsite.merchantAndProduct.controller;

public class PaymentController {
    private Long paymentId;
    private Double totalAmount;

}
