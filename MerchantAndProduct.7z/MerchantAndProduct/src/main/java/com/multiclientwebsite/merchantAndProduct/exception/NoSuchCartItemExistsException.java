package com.multiclientwebsite.merchantAndProduct.exception;

public class NoSuchCartItemExistsException extends Exception {
    public NoSuchCartItemExistsException(String cart_item_does_not_exists) {
    }
}
