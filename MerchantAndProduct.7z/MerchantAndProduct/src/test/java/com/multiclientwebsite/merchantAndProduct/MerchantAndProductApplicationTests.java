package com.multiclientwebsite.merchantAndProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MerchantAndProductApplicationTests {

	@Test
	void contextLoads() {
	}

 }








